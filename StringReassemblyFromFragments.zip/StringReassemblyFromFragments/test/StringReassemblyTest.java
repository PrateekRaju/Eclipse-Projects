import static org.junit.Assert.assertEquals;

import org.junit.Test;

import components.set.Set;
import components.set.Set1L;

public class StringReassemblyTest {

    /**
     * Routine test of combining strings with overlap
     */
    @Test
    public void testCombination() {
        String str1 = "osuisbetterthanmichigan";
        String str2 = "michigansucks";
        int overlap = 8;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("osuisbetterthanmichigansucks", result);
    }

    /**
     * Routine test of combining strings with overlap
     */
    @Test
    public void testCombination2() {
        String str1 = "whatsup";
        String str2 = "upguys";
        int overlap = 2;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("whatsupguys", result);
    }

    /**
     * Routine/Challenging test of combining strings with overlap All letters
     * overlap
     */
    @Test
    public void testCombination3() {
        String str1 = "stringisthesame";
        String str2 = "stringisthesame";
        int overlap = 15;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("stringisthesame", result);
    }

    /**
     * Routine/Challenging test of combining strings with overlap Only 1 letter
     * overlaps
     */
    @Test
    public void testCombination4() {
        String str1 = "bigboy";
        String str2 = "ysarebig";
        int overlap = 1;
        String result = StringReassembly.combination(str1, str2, overlap);
        assertEquals("bigboysarebig", result);
    }

    /**
     * Routine test of addToSetAvoidingSubstrings.
     */
    @Test
    public void testaddToSetAvoidingSubstrings() {
        Set<String> strset = new Set1L<String>();
        strset.add("Wow this is great!");
        strset.add("Right?");
        strset.add("So cool.");
        Set<String> strset2 = new Set1L<String>();
        strset2.add("Wow this is great!");
        strset2.add("Right?");
        strset2.add("So cool.");
        String str = "So cool.";
        StringReassembly.addToSetAvoidingSubstrings(strset, str);
        assertEquals(strset, strset2);
    }
}