import components.map.Map;
import components.map.Map1L;
import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.set.Set;
import components.set.Set1L;
import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Input a .txt file and output an html page with words and definitions
 *
 * @author Prateek Raju
 *
 */
public final class Glossary {

    /**
     * No argument constructor--private to prevent instantiation.
     */
    private Glossary() {
    }

    /**
     * Generates the terms and definitions and pairs them into the given
     * {@code Map} and into the given {@code Queue}
     *
     * @param file
     *            the given {@code file}
     * @param strMap
     *            the {@code Map} to be replaced
     * @param q
     *            the {@code Queue} to be replaced
     * @replaces {@code strSet}
     * @replaces {@code q}
     * @ensures <pre>
     * {@code strMap = elements(file)}
     * </pre>
     */
    public static void generateTerms(SimpleReader file,
            Map<String, String> strMap, Sequence<String> q) {

        int count = 0;
        String term = "";
        String definitionHolder = "test";
        String finalDefinition = "";

        while (!file.atEOS()) {
            term = file.nextLine();
            q.add(count, term);
            count++;
            definitionHolder = "Test";
            finalDefinition = "";

            // look for definition
            while (!definitionHolder.equals("")) {
                definitionHolder = file.nextLine();
                finalDefinition = finalDefinition.concat(definitionHolder);
            }
            // add the definition and term to the Map
            strMap.add(term, finalDefinition);
        }
    }

    /**
     * Puts the given {@code Sequence} in alphabetical order
     *
     * @param q
     *            the given {@code Sequence}
     * @replaces {@code q}
     */
    public static void alphabet(Sequence<String> q) {

        Sequence<String> newQ = new Sequence1L<String>();
        newQ.transferFrom(q);
        String n = "";
        int addCount = 0;
        while (newQ.length() != 0) {
            int count = 0;
            int nextCount = 0;
            while (count < newQ.length() - 1) {
                n = newQ.entry(nextCount);
                if (n.compareTo(newQ.entry(count + 1)) > 0) {
                    nextCount = count + 1;
                }
                count++;
            }
            q.add(addCount, newQ.entry(nextCount));
            newQ.remove(nextCount);
            addCount++;
        }

    }

    /**
     * Outputs the opening tags in the generated HTML file.
     *
     * @param terms
     *            the given (@code Sequence) of terms
     * @param out
     *            the output stream
     * @updates {@code out.content}
     * @ensures <pre>
     *  {@code out.content = #out.content * [the HTML opening tags]}
     *  </pre>
     */
    public static void outputIndex(Sequence<String> terms, SimpleWriter out) {
        // prints the opening tags
        out.println("<html>");
        out.println("<head>");

        // prints the title
        out.println("<title>Glossary</title>");

        // prints more opening tags
        out.println("</head>");
        out.println("<body>");
        out.println("<h2>Glossary</h2>");
        out.println("<h3>Index</h3>");
        out.println("<ul>");

        // prints each term's html
        int k = 0;
        while (k < terms.length()) {
            String termName = terms.entry(k);
            out.println("<li><a href=\"" + termName + ".html" + "\">" + termName
                    + "</a></li>");
            k++;
        }

        // prints the rest of the tags
        out.println("</ul>");
        out.println("</body>");
        out.println("</html>");
    }

    /**
     * Outputs the opening tags in the generated HTML file.
     *
     * @param m
     *            the {@code Map} of terms and definitions
     * @param terms
     *            the {@code Sequence} of terms
     * @param folderName
     *            the folder the html files are output to
     * @updates {@code out.content}
     * @ensures <pre>
     *  {@code out.content = #out.content * [the HTML opening tags]}
     *  </pre>
     */
    public static void outputDefinitions(Map<String, String> m,
            Sequence<String> terms, String folderName) {
        int count = 0;
        String fileName = "";
        while (count < terms.length()) {
            fileName = terms.entry(count);
            SimpleWriter out = new SimpleWriter1L(
                    folderName + "/" + fileName + ".html");

            // prints the opening tags
            out.println("<html>");
            out.println("<head>");

            // prints the title
            out.println("<title>" + terms.entry(count) + "</title>");

            out.println("</head>");

            // prints the  definition tags
            out.println("<h2><b><i><font color=\"red\">" + terms.entry(count)
                    + "</font></i></b></h2>");
            out.println("<blockquote>" + m.value(terms.entry(count))
                    + "</blockquote>");

            // prints the reference to index
            out.println("<p>Return to <a href=\"index.html\">index</a></p>");

            // prints the rest of the tags
            out.println("</body>");
            out.println("</html>");

            out.close();
            count++;
        }
    }

    /**
     * Returns the first "word" (maximal length string of characters not in
     * {@code separators}) or "separator string" (maximal length string of
     * characters in {@code separators}) in the given {@code text} starting at
     * the given {@code position}.
     *
     * @param text
     *            the {@code String} from which to get the word or separator
     *            string
     * @param position
     *            the starting index
     * @param separators
     *            the {@code Set} of separator characters
     * @return the first word or separator string found in {@code text} starting
     *         at index {@code position}
     * @requires <pre>
     * {@code 0 <= position < |text|}
     * </pre>
     * @ensures <pre>
     * {@code nextWordOrSeparator =
     * text[ position .. position + |nextWordOrSeparator| ) and
     * if elements(text[ position .. position + 1 )) intersection separators =
    {}
     * then
     * elements(nextWordOrSeparator) intersection separators = {} and
     * (position + |nextWordOrSeparator| = |text| or
     * elements(text[ position .. position + |nextWordOrSeparator| + 1 ))
     * intersection separators /= {})
     * else
     * elements(nextWordOrSeparator) is subset of separators and
     * (position + |nextWordOrSeparator| = |text| or
     * elements(text[ position .. position + |nextWordOrSeparator| + 1 ))
     * is not subset of separators)}
     * </pre>
     */
    public static String nextWordOrSeparator(String text, int position,
            Set<Character> separators) {
        assert text != null : "Violation of: text is not null";
        assert separators != null : "Violation of: separators is not null";
        assert 0 <= position : "Violation of: 0 <= position";
        assert position < text.length() : "Violation of: position < |text|";

        String result = "";
        int i = position;
        if (!separators.contains(text.charAt(position))) {
            while (i < text.length() && !separators.contains(text.charAt(i))) {
                i++;
            }
            result = text.substring(position, i);
        } else {
            while (i < text.length() && separators.contains(text.charAt(i))) {
                i++;
            }
            result = text.substring(position, i);
        }
        return result;
    }

    /**
     * Generates the set of characters in the given {@code String} into the
     * given {@code Set}.
     *
     * @param str
     *            the given {@code String}
     * @param strSet
     *            the {@code Set} to be replaced
     * @replaces {@code strSet}
     * @ensures <pre>
     * {@code strSet = elements(str)}
     * </pre>
     */
    public static void generateElements(String str, Set<Character> strSet) {
        assert str != null : "Violation of: str is not null";
        assert strSet != null : "Violation of: strSet is not null";

        char setPiece = 'a';
        strSet.clear();
        for (int i = 0; i < str.length(); i++) {
            if (!strSet.contains(str.charAt(i))) {
                setPiece = str.charAt(i);
                strSet.add(setPiece);
            }
        }
    }

    /**
     * Updates the given {@code Map} values with html hyperlink tags included
     * next to terms mentioned within definitions.
     *
     * @param map
     *            the given {@code Map}
     * @param sequence
     *            the {@code Sequence} to be used to update map
     * @param separatorSet
     *            the {@code Set} to be used to separate words from each other
     * @restores {@code sequence}
     * @replaces {@code map}
     */
    public static void mapUpdateLink(Map<String, String> map,
            Sequence<String> sequence, Set<Character> separatorSet) {
        Map<String, String> copy = new Map1L<String, String>();
        Set<String> terms = new Set1L<String>();
        String testCopy = "";
        int position = 0;
        int count = 0;
        int size = sequence.length();
        while (terms.size() < size) {
            testCopy = sequence.remove(count);
            terms.add(testCopy);
            sequence.add(count, testCopy);
            count++;
        }
        count = 0;
        testCopy = "";
        while (count < terms.size()) {
            position = 0;
            testCopy = "";
            String testStr = map.value(sequence.entry(count));
            while (position < testStr.length()) {
                String token = nextWordOrSeparator(testStr, position,
                        separatorSet);
                if (separatorSet.contains(token.charAt(0))) {
                    testCopy = testCopy + token;
                } else if (terms.contains(token)) {
                    testCopy = testCopy + "<a href=\"" + token + ".html\">"
                            + token + "</a>";
                } else {
                    testCopy = testCopy.concat(token);
                }
                position += token.length();
            }
            copy.add(sequence.entry(count), testCopy);
            count++;
        }
        map.transferFrom(copy);
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        // open input and output streams
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        // ask for input file
        out.println("Insert name of input file: ");
        SimpleReader file = new SimpleReader1L(in.nextLine());
        out.println("Insert name of output folder: ");
        String folder = in.nextLine();

        // creates a Map and Sequence of associated terms and definitions
        Map<String, String> m = new Map1L<String, String>();
        Sequence<String> terms = new Sequence1L<String>();
        generateTerms(file, m, terms);

        // sort the q of terms into alphabetical order
        alphabet(terms);

        // update the Map to have alphabetized terms and definitions paired together
        // update terms in Map to have hyperlink html tags associated with every term appearing in definitions
        final String separatorStr = " \t, ";
        Set<Character> separatorSet = new Set1L<Character>();
        generateElements(separatorStr, separatorSet);
        mapUpdateLink(m, terms, separatorSet);

        // create Index page
        SimpleWriter index = new SimpleWriter1L(folder + "/index.html");
        outputIndex(terms, index);
        index.close();

        // create definition pages
        outputDefinitions(m, terms, folder);

        in.close();
        out.close();
        file.close();
    }
}
