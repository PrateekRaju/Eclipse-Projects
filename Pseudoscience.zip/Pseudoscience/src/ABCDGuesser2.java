import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Uses the de Jager Formula to approximate a random constant using numbers
 * meaningful to user then prints out estimation and the relative error from the
 * actual value then reports the exponents a, b, c, and d as part of the
 * calculation
 *
 * @author Prateek Raju
 *
 */
public final class ABCDGuesser2 {

    private ABCDGuesser2() {
        // no code needed here
    }

    /**
     * Repeatedly asks the user for a positive real number until the user enters
     * one. Returns the positive real number.
     *
     * @param constant
     *            constant used for calculation in the de Jager formula
     * @param a
     *            first exponent assigned to w
     * @param b
     *            second exponent assigned to x
     * @param c
     *            third exponent assigned to y
     * @param d
     *            fourth exponent assigned to z
     */
    private static void getPositiveDouble(double constant, double a, double b,
            double c, double d) {
        int num1 = 0;
        int num2 = 0;
        int num3 = 0;
        int num4 = 0;
        double num1Count = 0;
        double num2Count = 0;
        double num3Count = 0;
        double num4Count = 0;
        double[] deJagarList = { -5, -4, -3, -2, -1, -1.0 / 2, -1.0 / 3,
                -1.0 / 4, 0, 1.0 / 4, 1.0 / 3, 1.0 / 2, 1, 2, 3, 4, 5 };
        double difference = ((Math.pow(a, deJagarList[0]))
                * (Math.pow(b, deJagarList[0])) * (Math.pow(c, deJagarList[0]))
                * (Math.pow(c, deJagarList[0]))) - constant;

        for (num4 = 0; num4 <= 16; num4++) {
            for (num3 = 0; num3 <= 16; num3++) {
                for (num2 = 0; num2 <= 16; num2++) {
                    for (num1 = 0; num1 <= 16; num1++) {
                        double estimation = ((Math.pow(a, deJagarList[num1]))
                                * Math.pow(b, deJagarList[num2]))
                                * Math.pow(c, deJagarList[num3])
                                * Math.pow(d, deJagarList[num4]) - constant;
                        if (Math.abs(estimation) < Math.abs(difference)) {
                            difference = estimation;
                            num1Count = deJagarList[num1];
                            num2Count = deJagarList[num2];
                            num3Count = deJagarList[num3];
                            num4Count = deJagarList[num4];
                        }
                    }
                    num1 = 0;
                }
                num2 = 0;
            }
            num3 = 0;
        }

        double error = (difference / constant) * 100;

        SimpleWriter out = new SimpleWriter1L();
        out.println(constant + difference);
        out.println("The error is: " + error);
        out.println("The exponent of the first number: " + num1Count);
        out.println("The exponent of the second number: " + num2Count);
        out.println("The exponent of the third number: " + num3Count);
        out.println("The exponent of the fourth number: " + num4Count);

        out.close();
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments; unused here
     */
    public static void main(String[] args) {
        SimpleReader inData = new SimpleReader1L();
        SimpleWriter outData = new SimpleWriter1L();
        double firstNum;
        double secondNum;
        double thirdNum;
        double fourthNum;

        outData.println("Enter constant to approximate: ");
        double constant = inData.nextDouble();
        outData.println(
                "Choose positive numbers that are significant to you that are not '1'");
        outData.println("Enter first number: ");
        firstNum = inData.nextDouble();
        outData.println("Enter second number: ");
        secondNum = inData.nextDouble();
        outData.println("Enter third number: ");
        thirdNum = inData.nextDouble();
        outData.println("Enter fourth number: ");
        fourthNum = inData.nextDouble();
        getPositiveDouble(constant, firstNum, secondNum, thirdNum, fourthNum);

        inData.close();
        outData.close();
    }

}
