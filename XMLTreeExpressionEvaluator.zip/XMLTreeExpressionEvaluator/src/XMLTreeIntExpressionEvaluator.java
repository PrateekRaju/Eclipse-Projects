import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;
import components.xmltree.XMLTree;
import components.xmltree.XMLTree1;

/**
 * Program to evaluate XMLTree expressions of {@code int}.
 *
 * @author Prateek Raju
 *
 */
public final class XMLTreeIntExpressionEvaluator {

    /**
     * Private constructor so this utility class cannot be instantiated.
     */
    private XMLTreeIntExpressionEvaluator() {
    }

    /**
     * Evaluate the given expression.
     *
     * @param exp
     *            the {@code XMLTree} representing the expression
     * @return the value of the expression
     * @requires <pre>
     * [exp is a subtree of a well-formed XML arithmetic expression]  and
     *  [the label of the root of exp is not "expression"]
     * </pre>
     * @ensures evaluate = [the value of the expression]
     */
    private static int evaluate(XMLTree exp) {
        assert exp != null : "Violation of: exp is not null";
        int value = 0;
        int childOne = 0;
        int childTwo = 0;
        while (exp.numberOfChildren() != 0) {
            // convert String values to integer values to add
            if (exp.label() == "plus") {
                if (exp.child(0).hasAttribute("number") == true) {
                    String child1 = exp.child(0).attributeValue("number");
                    childOne = Integer.parseInt(child1);
                } else {
                    // make it recursive
                    evaluate(exp.child(0));
                }
                if (exp.child(1).hasAttribute("number") == true) {
                    String child2 = exp.child(0).attributeValue("number");
                    childTwo = Integer.parseInt(child2);
                } else {
                    // make it recursive
                    evaluate(exp.child(1));
                }
                // add and set value to result
                value = childOne + childTwo;
                // convert String values to integer values to subtract
            } else if (exp.label() == "minus") {
                if (exp.child(0).hasAttribute("number") == true) {
                    String child1 = exp.child(0).attributeValue("number");
                    childOne = Integer.parseInt(child1);
                } else {
                    // make it recursive
                    evaluate(exp.child(0));
                }
                if (exp.child(1).hasAttribute("number") == true) {
                    String child2 = exp.child(0).attributeValue("number");
                    childTwo = Integer.parseInt(child2);
                } else {
                    // make it recursive
                    evaluate(exp.child(1));
                }
                // subtract and set value to result
                value = childOne + childTwo;
                // convert String values to integer values to multiply
            } else if (exp.label() == "times") {
                if (exp.child(0).hasAttribute("number") == true) {
                    String child1 = exp.child(0).attributeValue("number");
                    childOne = Integer.parseInt(child1);
                } else {
                    // make it recursive
                    evaluate(exp.child(0));
                }
                if (exp.child(1).hasAttribute("number") == true) {
                    String child2 = exp.child(0).attributeValue("number");
                    childTwo = Integer.parseInt(child2);
                } else {
                    // make it recursive
                    evaluate(exp.child(1));
                }
                // multiply and set value to result
                value = childOne + childTwo;
                // convert String values to integer values to divide
            } else if (exp.label() == "divide") {
                if (exp.child(0).hasAttribute("number") == true) {
                    String child1 = exp.child(0).attributeValue("number");
                    childOne = Integer.parseInt(child1);
                } else {
                    // make it recursive
                    evaluate(exp.child(0));
                }
                if (exp.child(1).hasAttribute("number") == true) {
                    String child2 = exp.child(0).attributeValue("number");
                    childTwo = Integer.parseInt(child2);
                } else {
                    // make it recursive
                    evaluate(exp.child(1));
                }
                // divide and set value to result
                value = childOne / childTwo;
            }
        }
        return value;
    }

    /**
     * Main method.
     *
     * @param args
     *            the command line arguments
     */
    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        out.print("Enter the name of an expression XML file: ");
        String file = in.nextLine();
        while (!file.equals("")) {
            XMLTree exp = new XMLTree1(file);
            out.println(evaluate(exp.child(0)));
            out.print("Enter the name of an expression XML file: ");
            file = in.nextLine();
        }

        in.close();
        out.close();
    }

}