import java.util.Scanner;

import components.simplereader.SimpleReader;
import components.simplereader.SimpleReader1L;
import components.simplewriter.SimpleWriter;
import components.simplewriter.SimpleWriter1L;

/**
 * Estimates square root of x within a relative error of 0.01%
 *
 * @author Prateek Raju
 *
 */
public class Newton3 {

    public static double sqrt(double c, double Epsilon) {
        if (c < 0) {
            return Double.NaN;
        }
        if (c == 0) {
            return 0;
        }
        double t = c;
        while (Math.abs(t - c / t) > Epsilon * t) {
            t = (c / t + t) / 2;
        }
        return t;
    }

    public static void main(String[] args) {
        SimpleReader in = new SimpleReader1L();
        SimpleWriter out = new SimpleWriter1L();

        Scanner s = new Scanner(System.in);
        double x = 0;
        double epsilon = 0.0;
        String y = "y";
        while (('y' == y.charAt(0)) && y.length() == 1) {
            System.out.println("Enter a number: ");
            x = s.nextDouble();
            System.out.println("Enter epsilon value : ");
            epsilon = s.nextDouble();
            System.out.println("Square root: " + sqrt(x, epsilon));
            System.out.println("Do you want to continue: ");
            y = s.next();
        }

        in.close();
        out.close();
    }

}
